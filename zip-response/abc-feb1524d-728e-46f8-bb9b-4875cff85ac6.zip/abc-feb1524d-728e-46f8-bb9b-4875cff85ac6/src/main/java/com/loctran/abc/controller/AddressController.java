package com.loctran.abc.controller;

import com.loctran.abc.entity.Address;
import com.loctran.abc.service.AddressService;
import com.loctran.abc.dto.AddressDto;
import com.loctran.abc.dto.ResponseDto;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Date;

@RestController
@RequiredArgsConstructor
@RequestMapping("api/addresss")
public class AddressController {

private final AddressService service;
private final HttpServletRequest httpServletRequest;

	@GetMapping("")
	 public Object fetchEntities(@RequestParam(value = "current_page", defaultValue = "1", required = false) int currentPage,
	 @RequestParam(value = "page_size", defaultValue = "10") int pageSize,
	 @RequestParam(value = "sort_by", defaultValue = "id") String sortBy,
	 @RequestParam(value = "sort_dir", defaultValue = "desc", required = false) String sortDir) {

	 	 	Page<Address> entities = service.fetchEntities(currentPage, pageSize, sortBy, sortDir);
	 	 	ResponseDto responseDto = ResponseDto.builder()
	 	 	.timestamp(new Date())
	 	 	.status(HttpStatus.CREATED)
	 	 	.path(httpServletRequest.getContextPath())
	 	 	.data(entities)
	 	 	.errors(null)
	 	 	.message("Process Successfully!")
	 	 	.build();
	 	 	return ResponseEntity.status(HttpStatus.OK).body(responseDto);
	 	}
	@GetMapping("{id}")
	 public Object fetchDetails(@RequestParam(value = "id") Integer id) {
	 	Address entity = service.fetchEntity(id);
	 	 	ResponseDto responseDto = ResponseDto.builder()
	 	 	.timestamp(new Date())
	 	 	.status(HttpStatus.CREATED)
	 	 	.path(httpServletRequest.getContextPath())
	 	 	.data(entity)
	 	 	.errors(null)
	 	 	.message("Process Successfully!")
	 	 	.build();
	 	 	return ResponseEntity.status(HttpStatus.OK).body(responseDto);
	 	}
	@PostMapping("")
	 public Object createEntity(@RequestParam("userId") Integer userId,@RequestBody AddressDto dto) {
	 	Address entity = service.createEntity(userId,dto);
	 	 	ResponseDto responseDto = ResponseDto.builder()
	 	 	.timestamp(new Date())
	 	 	.status(HttpStatus.CREATED)
	 	 	.path(httpServletRequest.getContextPath())
	 	 	.data(entity)
	 	 	.errors(null)
	 	 	.message("Process Successfully!")
	 	 	.build();
	 	 	return ResponseEntity.status(HttpStatus.OK).body(responseDto);
	 	}
	@PutMapping("{id}")
	 public Object updateEntity(@PathVariable("id")Integer id,@RequestBody AddressDto dto) {
	 	Address entity = service.updateEntity(dto,id);
	 	 	ResponseDto responseDto = ResponseDto.builder()
	 	 	.timestamp(new Date())
	 	 	.status(HttpStatus.OK)
	 	 	.path(httpServletRequest.getContextPath())
	 	 	.data(entity)
	 	 	.errors(null)
	 	 	.message("Process Successfully!")
	 	 	.build();
	 	 	return ResponseEntity.status(HttpStatus.OK).body(responseDto);
	 	}
	@DeleteMapping("{id}")
	 public Object deleteEntity(@PathVariable("id")Integer id) {
	 	Address entity = service.deleteEntity(id);
	 	 	ResponseDto responseDto = ResponseDto.builder()
	 	 	.timestamp(new Date())
	 	 	.status(HttpStatus.OK)
	 	 	.path(httpServletRequest.getContextPath())
	 	 	.data(entity)
	 	 	.errors(null)
	 	 	.message("Process Successfully!")
	 	 	.build();
	 	 	return ResponseEntity.status(HttpStatus.OK).body(responseDto);
	 	}
}
